﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using MySqlConnector;
namespace QuizTimeSpel
{
    class Answer
    {
        private Int32 _ID;
        private string _RightOrWrongA;
        private string _RightOrWrongB;
        private string _RightOrWrongC;
        private string _RightOrWrongD;
        private string _Awnser;
        private Int32 _Answer_question_ID;

        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        public string RightOrWrongA
        {
            get { return _RightOrWrongA; }
            set { _RightOrWrongA = value; }
        }
        public string RightOrWrongB
        {
            get { return _RightOrWrongB; }
            set { _RightOrWrongB = value; }
        }
        public string RightOrWrongC
        {
            get { return _RightOrWrongC; }
            set { _RightOrWrongC = value; }
        }
        public string RightOrWrongD
        {
            get { return _RightOrWrongD; }
            set { _RightOrWrongD = value; }
        }
        public string Awnser
        {
            get { return _Awnser; }
            set { _Awnser = value; }
        }

        public int Answer_question_ID
        {
            get { return _Answer_question_ID; }
            set { _Answer_question_ID = value; }
        }


        SQL sql = new SQL();

        public void ReadAnswer(Int32 ID)
        {
            string SQL = string.Format("SELECT ID, Answer FROM quiztime.answer WHERE ID = {0}", ID);
            DataTable datatable = sql.getDataTable(SQL);
            _ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
            _Awnser = datatable.Rows[0]["Answer"].ToString();
        }

        public void ReadAnswer(Int32 ID, SpelPagina form)
        {
            string SQL = string.Format("SELECT a.ID, Answer, Question_ID FROM answer AS a LEFT JOIN question AS q ON q.ID=a.question_ID WHERE q.ID = {0} ORDER BY RAND() LIMIT 4", ID);
            DataTable datatable = sql.getDataTable(SQL);
            try
            {
                _ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
                form.btnA.Content = datatable.Rows[0]["Answer"].ToString();
                form.btnB.Content = datatable.Rows[1]["Answer"].ToString();
                form.btnC.Content = datatable.Rows[2]["Answer"].ToString();
                form.btnD.Content = datatable.Rows[3]["Answer"].ToString();
                _Answer_question_ID = Convert.ToInt32(datatable.Rows[0]["Question_ID"].ToString());
            }
            catch (Exception)
            {

                throw new ArgumentException("Quiz over");
            }
        }


        public void ReadAnswer(Int32 ID, KijknaPagina form)
        {
            string SQL = string.Format("SELECT a.ID, Answer, RightOrWrong, Question_ID FROM answer AS a LEFT JOIN question AS q ON q.ID=a.question_ID WHERE q.ID = {0} ORDER BY RAND() LIMIT 4", ID);
            DataTable datatable = sql.getDataTable(SQL);
            try
            {
                _RightOrWrongA = datatable.Rows[0]["RightOrWrong"].ToString();
                _RightOrWrongB = datatable.Rows[1]["RightOrWrong"].ToString();
                _RightOrWrongC = datatable.Rows[2]["RightOrWrong"].ToString();
                _RightOrWrongD = datatable.Rows[3]["RightOrWrong"].ToString();
                _ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
                form.btnA.Content = datatable.Rows[0]["Answer"].ToString();
                form.btnB.Content = datatable.Rows[1]["Answer"].ToString();
                form.btnC.Content = datatable.Rows[2]["Answer"].ToString();
                form.btnD.Content = datatable.Rows[3]["Answer"].ToString();
                _Answer_question_ID = Convert.ToInt32(datatable.Rows[0]["Question_ID"].ToString());
            }
            catch (Exception)
            {

                throw new ArgumentException("Quiz over");
            }
        }
        public void Create_answer(string Answer, int Quest_ID, int Quiz_ID)
        {
            string SQL = string.Format("INSERT INTO quiztime.answer (RightOrWrong, Answer, question_ID, quiz_ID) VALUES ('Fout', '{0}', '{1}', '{2}')",
                         Answer, Quest_ID, Quiz_ID);

            sql.ExecuteNonQuery(SQL);
        }
        public void Create_Currect_answer(string Answer, int Quest_ID, int Quiz_ID)
        {
            string SQL = string.Format("INSERT INTO quiztime.answer (RightOrWrong, Answer, question_ID, quiz_ID) VALUES ('Goed', '{0}', '{1}', '{2}')",
                         Answer, Quest_ID, Quiz_ID);

            sql.ExecuteNonQuery(SQL);
        }

        public DataSet getDataAnswer()
        {
            string SQL = "SELECT ID, Answer, question_ID FROM quiztime.answer";

            return sql.getDataSet(SQL);
        }

        public bool DeleteA(Int32 ID)
        {
            bool isDeleted = false;
            if (System.Windows.MessageBox.Show("Moeten deze gegevens verwijderd worden?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                string SQL = string.Format("DELETE FROM quiztime.answer WHERE ID = {0};", ID);

                sql.ExecuteNonQuery(SQL);
                isDeleted = true;

            }
            return isDeleted;
        }
        public void DeleteAllAnswers_Quiz(Int32 AnswerID)
        {

            string SQL = string.Format("DELETE FROM quiztime.answer WHERE quiz_ID = {0};", AnswerID);

            sql.ExecuteNonQuery(SQL);

        }
        public void DeleteAllAnswers_Question(Int32 question_ID)
        {

            string SQL = string.Format("DELETE FROM quiztime.answer WHERE question_ID = {0};", question_ID);

            sql.ExecuteNonQuery(SQL);

        }

        public void UpdateAnswer(int id, string Answer)
        {
            string SQL = string.Format("Update quiztime.answer " +
                                       "Set Answer  = '{0}' " +
                                       "WHERE ID =  {1}",
                                        Answer,
                                        id.ToString());
            sql.ExecuteNonQuery(SQL);
        }
    }
}

