﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for KiesPagina.xaml
    /// </summary>
    public partial class CRUDPagina : Window
    {
        Quiz quiz = new Quiz();
        Questionn QA = new Questionn();
        Answer Answer = new Answer();
        public CRUDPagina()
        {
            InitializeComponent();
            btnAdd.Click += BtnAdd_Click;
            btnMainWindow.Click += BtnMainWindow_Click;
            dgQuiz.DataContext = quiz.getData();
            dgQuestion.DataContext = QA.getDataQuestion();
            dgAnsewr.DataContext = Answer.getDataAnswer();
            btnEditQuiz.Click += BtnEditQuiz_Click;
            btnEditQuestion.Click += BtnEditQuestion_Click;
            btnEditAnswer.Click += BtnEditAnswer_Click;
            btnBack.Click += BtnBack_Click;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            CRUDPagina window = new CRUDPagina();
            window.Show();
            this.Close();
        }

        private void hide()
        {
            btnEditAnswer.Visibility = Visibility.Hidden;
            btnEditQuestion.Visibility = Visibility.Hidden;
            btnEditQuiz.Visibility = Visibility.Hidden;
            btnMainWindow.Visibility = Visibility.Hidden;
            btnBack.Visibility = Visibility.Visible;

        }

        private void BtnEditAnswer_Click(object sender, RoutedEventArgs e)
        {
            hide();
            dgAnsewr.Visibility = Visibility.Visible;

        }

        private void BtnEditQuestion_Click(object sender, RoutedEventArgs e)
        {
            hide();
            dgQuestion.Visibility = Visibility.Visible;
        }

        private void BtnEditQuiz_Click(object sender, RoutedEventArgs e)
        {
            hide();
            dgQuiz.Visibility = Visibility.Visible;
        }

        private void BtnMainWindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                object item = dgQuiz.SelectedItem;
                int ID = int.Parse((dgQuiz.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                if (quiz.Delete(ID) == true)
                {
                    dgQuiz.DataContext = quiz.getData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }



        private void btnDelete_Question_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                object item = dgQuestion.SelectedItem;
                int ID = int.Parse((dgQuestion.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                if (QA.DeleteQ(ID) == true)
                {
                    dgQuestion.DataContext = QA.getDataQuestion();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }
        private void btnDelete_Answer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                object item = dgAnsewr.SelectedItem;
                int ID = int.Parse((dgAnsewr.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                if (Answer.DeleteA(ID) == true)
                {
                    dgAnsewr.DataContext = Answer.getDataAnswer();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }


        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                object item = dgQuiz.SelectedItem;
                int ID = int.Parse((dgQuiz.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                EditQQA window = new EditQQA(ID);
                window.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }


        private void btnEdit_Quest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                object item = dgQuestion.SelectedItem;
                int ID = int.Parse((dgQuestion.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                EditQA window = new EditQA(ID);
                window.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }


        private void btnEdit_Answer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                object item = dgAnsewr.SelectedItem;
                int ID = int.Parse((dgAnsewr.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                EditAnswer window = new EditAnswer(ID);
                window.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }


        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ToevoegenPagina window = new ToevoegenPagina();
            window.Show();
            this.Close();
        }
        
    }
}