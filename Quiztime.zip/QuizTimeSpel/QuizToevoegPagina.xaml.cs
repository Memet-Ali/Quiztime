﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for QuizToevoegPagina.xaml
    /// </summary>
    public partial class QuizToevoegPagina : Window
    {
        Quiz quiz = new Quiz();
        public QuizToevoegPagina()
        {
            InitializeComponent();
            btnToevoegen.Click += BtnToevoegen_Click;
            btnMainWindow.Click += BtnMainWindow_Click;
            btnBack.Click += BtnBack_Click;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ToevoegenPagina window = new ToevoegenPagina();
            window.Show();
            this.Close();
        }

        private void BtnMainWindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void BtnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            if(txbNieuweQuiz.Text == string.Empty)
            {
                lblError.Content = "Vul eerst een Quiznaam in!";
                return;
                lblError.Foreground = Brushes.DarkRed;
            }
            else
            {
                lblError.Content = "Er is een nieuwe Quiz toegevoegd met de naam " + txbNieuweQuiz.Text;

                lblError.Foreground = Brushes.LightSeaGreen;
            }
            quiz.Create(txbNieuweQuiz.Text);

        }
       }
    }
