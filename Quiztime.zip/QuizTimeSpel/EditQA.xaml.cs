﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for EditQA.xaml
    /// </summary>
    public partial class EditQA : Window
    {
        Questionn QA = new Questionn();
        public EditQA()
        {
            InitializeComponent();
            btnUpdateQA.Click += BtnUpdateQA_Click;
            btn_back.Click += btn_back_Click;
            btn_backMain.Click += Btn_backMain_Click;
            btnKiezFoto.Click += BtnKiezFoto_Click;
        }

        private void Btn_backMain_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
        private void btn_back_Click(object sender, RoutedEventArgs e)
        {
            CRUDPagina terug = new CRUDPagina();
            terug.Show();
            this.Close();
        }


        public EditQA(Int32 ID)
        {
            InitializeComponent();
            QA.ReadQuestion(ID);

            txbID.Text = QA.question_ID.ToString();
            txbVraag.Text = QA.Question;
            lbl_foto.Content = QA.img;
            btnUpdateQA.Click += BtnUpdateQA_Click;
        }
        private void BtnKiezFoto_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG|*.jpg", ValidateNames = true, Multiselect = false };
            {
                bool? result = ofd.ShowDialog();
                if (result == true)
                {
                    string file = string.Empty;
                    file = ofd.SafeFileName;
                    lbl_foto.Content = file;
                }
            }
        }

        private void BtnUpdateQA_Click(object sender, RoutedEventArgs e)
        {
            if (txbVraag.Text == string.Empty)
            {
                lblError.Content = "Het vraag mag niet leeg zijn!";
                return;
            }
            QA.UpdateQuestion(Convert.ToInt32(txbID.Text),
                                lbl_foto.Content.ToString(),
                                txbVraag.Text);

            CRUDPagina window = new CRUDPagina();
            window.Show();
            this.Close();
        }

    }
}
