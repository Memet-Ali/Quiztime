﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace QuizTimeSpel
{

    public class QuizItem
    {

        public string Text { get; set; }
        public int id { get; set; }

        public override string ToString()
        {
            return Text;
        }
    }

    class SQL
    {
        public int LastInsertedID { get; set; }
        MySqlConnection conn = new MySqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

        public DataSet getDataSet(string SQL)
        {
            DataSet dataset = new DataSet();

            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(SQL, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
                adp.Fill(dataset, "LoadDataBinding");
                conn.Close();
            }
            catch (MySqlException ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

            return dataset;
        }

        public void ComboBoxQuizjes(ComboBox cb, Label extxt)
        {
            try
            {
                conn.Open();

                string selectQuery = "SELECT ID, Quiz_name FROM quiztime.quiz";
                MySqlCommand command = new MySqlCommand(selectQuery, conn);
                MySqlDataReader reader = command.ExecuteReader();



                while (reader.Read())
                {
                    string quizjess = reader.GetString("Quiz_name");
                    int id = reader.GetInt32("ID");
                    cb.Items.Add(new QuizItem()
                    {
                        Text = quizjess,
                        id = id
                    });
                }
                conn.Close();

            }
            catch (Exception ex)
            {
                extxt.Content = ex.Message;
            }
        }

        public DataTable getDataTable(string SQL)
        {
            DataTable datatable = new DataTable();

            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(SQL, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
                adp.Fill(datatable);
                conn.Close();
            }
            catch (MySqlException ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

            return datatable;
        }
        public void ExecuteNonQuery(string SQL)
        {
            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(SQL, conn);
                cmd.ExecuteNonQuery();
                LastInsertedID = (int)cmd.LastInsertedId;
                conn.Close();
            }
            catch (MySqlException ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }
    }
}
