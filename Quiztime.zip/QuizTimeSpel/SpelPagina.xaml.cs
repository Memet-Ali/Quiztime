﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for SpelPagina.xaml
    /// </summary>
    public partial class SpelPagina : Window
    {

        Questionn QA = new Questionn();
        Answer answer = new Answer();
        public int QID;
        public int QuestionNr;
        public int Tijd = 10;

        DispatcherTimer timer = new DispatcherTimer();
        public SpelPagina(int Quiz_ID)
        {


            InitializeComponent();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick; ;
            timer.Start();

            

            QID = Quiz_ID;
            QuestionNr = QA.question_ID;
            btnVolgende.Click += BtnVolgende_Click;
            btnSluiten.Click += BtnSluiten_Click;
            btnMain.Click += BtnMain_Click;
            try
            {
                QA.GetQuestionID(Quiz_ID);
                QA.ReadQuestion(Quiz_ID, this);
                answer.ReadAnswer(QA.question_ID, this);
            }catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
                return;
            }
        }

        private void BtnMain_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnSluiten_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        private void hide()
        {
            txbQuestion.Visibility = Visibility.Hidden;
            btnA.Visibility = Visibility.Hidden;
            btnB.Visibility = Visibility.Hidden;
            btnC.Visibility = Visibility.Hidden;
            btnD.Visibility = Visibility.Hidden;
            R1.Visibility = Visibility.Hidden;
            R2.Visibility = Visibility.Hidden;
            R3.Visibility = Visibility.Hidden;
            R4.Visibility = Visibility.Hidden;
            R5.Visibility = Visibility.Hidden;
            R6.Visibility = Visibility.Hidden;
            R8.Visibility = Visibility.Hidden;
            lblTijd.Visibility = Visibility.Hidden;
            imgImg.Visibility = Visibility.Hidden;
        }

        private void Timer_Tick(object sender, EventArgs e){
            Tijd--;
            lblTijd.Content = Tijd.ToString();
            if (Tijd == 0)
            {
                timer.Stop();
                hide();
                lblNext.Visibility = Visibility.Visible;
            }

        }
        

        private void BtnVolgende_Click(object sender, RoutedEventArgs e)
        {

            lblTijd.Content = 10;
            Tijd = 10;
            timer.Start();

            txbQuestion.Visibility = Visibility.Visible;
            btnA.Visibility = Visibility.Visible;
            btnB.Visibility = Visibility.Visible;
            btnC.Visibility = Visibility.Visible;
            btnD.Visibility = Visibility.Visible;
            R1.Visibility = Visibility.Visible;
            R2.Visibility = Visibility.Visible;
            R3.Visibility = Visibility.Visible;
            R4.Visibility = Visibility.Visible;
            R5.Visibility = Visibility.Visible;
            R6.Visibility = Visibility.Visible;
            R8.Visibility = Visibility.Visible;
            lblTijd.Visibility = Visibility.Visible;
            imgImg.Visibility = Visibility.Visible;
            lblNext.Visibility = Visibility.Hidden;


            try
            {
                QA.GetQuestionID(QID);
                QA.ReadQuestion(QID, this);
                answer.ReadAnswer(QA.Next_id, this);
            }
            catch (ArgumentException)
            {
                timer.Stop();
                hide();
                lblNext.Visibility = Visibility.Visible;
                btnVolgende.Visibility = Visibility.Hidden;
                btnSluiten.Visibility = Visibility.Visible;
                lblNext.Content = "Klaar!";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
