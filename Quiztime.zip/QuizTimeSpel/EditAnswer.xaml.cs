﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for EditAnswer.xaml
    /// </summary>
    public partial class EditAnswer : Window
    {
        Answer answer = new Answer();
        public EditAnswer()
        {
            InitializeComponent();
            btnUpdateA.Click += BtnUpdateA_Click;
            btn_back.Click += btn_back_Click;
            btn_backMain.Click += Btn_backMain_Click;
        }

        private void Btn_backMain_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }



        public EditAnswer(Int32 ID)
        {
            InitializeComponent();
            answer.ReadAnswer(ID);

            txbID.Text = answer.ID.ToString();
            txbAntwoord.Text = answer.Awnser;
            btnUpdateA.Click += BtnUpdateA_Click;
        }

        private void BtnUpdateA_Click(object sender, RoutedEventArgs e)
        {
            if (txbAntwoord.Text == string.Empty)
            {
                lblError.Content = "De Antwoord mag niet leeg zijn!";
                return;
            }

            answer.UpdateAnswer(Convert.ToInt32(txbID.Text),
                                txbAntwoord.Text);

            CRUDPagina window = new CRUDPagina();
            window.Show();
            this.Close();
        }

        private void btn_back_Click(object sender, RoutedEventArgs e)
        {
            CRUDPagina terug = new CRUDPagina();
            terug.Show();
            this.Close();
        }
    }
}
