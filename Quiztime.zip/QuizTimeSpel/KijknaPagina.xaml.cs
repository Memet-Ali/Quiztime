﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for KijknaPagina.xaml
    /// </summary>
    public partial class KijknaPagina : Window
    {

        Questionn QA = new Questionn();
        Answer answer = new Answer();
        public int QID;
        public int QuestionNr;


        public KijknaPagina(int Quiz_ID)
        {
            InitializeComponent();



            QID = Quiz_ID;
            QuestionNr = QA.question_ID;
            btnVolgende.Click += BtnVolgende_Click;
            btnMainNa.Click += BtnMainNa_Click;
            try
            {
                QA.GetQuestionID(Quiz_ID);
                QA.ReadQuestion(Quiz_ID, this);
                answer.ReadAnswer(QA.question_ID, this);
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
                return;
            }
            CurrectAnswar();
        }

        private void BtnMainNa_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

       
        private void BtnVolgende_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                QA.GetQuestionID(QID);
                QA.ReadQuestion(QID, this);
                answer.ReadAnswer(QA.Next_id, this);
            }
            catch (ArgumentException)
            {

                MessageBox.Show("Quiz is over");
                MainWindow window = new MainWindow();
                window.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            CurrectAnswar();
        }
        private void CurrectAnswar()
        {
            if (answer.RightOrWrongA == "Goed")
            {
                btnA.Background = Brushes.Green;
                btnB.Background = Brushes.Red;
                btnC.Background = Brushes.Red;
                btnD.Background = Brushes.Red;

            }
            else if (answer.RightOrWrongB == "Goed")
            {
                btnB.Background = Brushes.Green;
                btnA.Background = Brushes.Red;
                btnC.Background = Brushes.Red;
                btnD.Background = Brushes.Red;
            }
            else if (answer.RightOrWrongC == "Goed")
            {
                btnC.Background = Brushes.Green;
                btnB.Background = Brushes.Red;
                btnA.Background = Brushes.Red;
                btnD.Background = Brushes.Red;
            }
            else if (answer.RightOrWrongD == "Goed")
            {
                btnD.Background = Brushes.Green;
                btnA.Background = Brushes.Red;
                btnC.Background = Brushes.Red;
                btnB.Background = Brushes.Red;
            }
        }
    }
}
