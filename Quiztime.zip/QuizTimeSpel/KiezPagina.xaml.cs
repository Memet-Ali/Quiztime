﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for KiezPagina.xaml
    /// </summary>
    public partial class KiezPagina : Window
    {
        SQL sql = new SQL();
        Questionn QA = new Questionn();
        public KiezPagina()
        {

            InitializeComponent();
            btnSpellen.Click += BtnSpellen_Click;
            btnBackMain.Click += BtnBackMain_Click;
            CbQuizSpel.SelectionChanged += CbQuizSpel_SelectionChanged;
            sql.ComboBoxQuizjes(CbQuizSpel, lblQuizID);

        }

        private void CbQuizSpel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
             if ((CbQuizSpel.SelectedValue != null) || !string.IsNullOrEmpty(CbQuizSpel.Text))
            {
                lblError.Content = "";
            }

            QuizItem q = (QuizItem)CbQuizSpel.SelectedItem;
            lblQuizID.Content = q.id;

        }

        private void BtnBackMain_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void BtnSpellen_Click(object sender, RoutedEventArgs e)
        {
            if ((CbQuizSpel.SelectedValue == null) || string.IsNullOrEmpty(CbQuizSpel.Text))
            {
                lblError.Content = "Selecteer eerst een Quiz";
                return;
            }
           
            SpelPagina SpelWindow = new SpelPagina(Convert.ToInt32(lblQuizID.Content));
            SpelWindow.Show();
            
        }
    }
}
