﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            btnQuizKiezen.Click += BtnQuizKiezen_Click;
            btnBewerkToevoeg.Click += BtnBewerkToevoeg_Click;
            btnNaKijken.Click += BtnNaKijken_Click;
        }

        private void BtnNaKijken_Click(object sender, RoutedEventArgs e)
        {
            NakijkenPagina window = new NakijkenPagina();
            window.Show();
            this.Close();
        }


        private void BtnBewerkToevoeg_Click(object sender, RoutedEventArgs e)
        {
            CRUDPagina window = new CRUDPagina();
            window.Show();
            this.Close();
        }

        private void BtnQuizKiezen_Click(object sender, RoutedEventArgs e)
        {
            KiezPagina window = new KiezPagina();
            window.Show();
            this.Close();
        }
    }
}
