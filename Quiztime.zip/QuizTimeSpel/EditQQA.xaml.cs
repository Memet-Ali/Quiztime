﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for EditQQA.xaml
    /// </summary>
    public partial class EditQQA : Window
    {
        Quiz quiz = new Quiz();
        public EditQQA()
        {
            InitializeComponent();
            btnUpdate.Click += BtnUpdate_Click;
        }


        public EditQQA(Int32 ID)
        {
            InitializeComponent();
            quiz.Read(ID);

            txbEditID.Text = quiz.ID.ToString();
            txbEditQuiz.Text = quiz.Quiz_name;
            btnUpdate.Click += BtnUpdate_Click;
        }

        private void Btn_backMain_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
        private void btn_back_Click(object sender, RoutedEventArgs e)
        {
            CRUDPagina terug = new CRUDPagina();
            terug.Show();
            this.Close();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if(txbEditQuiz.Text == string.Empty)
            {
                lblError.Content = "De Quiznaam mag niet leeg zijn!";
                return;
            }


            if (txbEditID.Text == string.Empty)
            {
                quiz.Create(txbEditQuiz.Text);
            }
            else
            {
                quiz.Update(txbEditID.Text,
                                txbEditQuiz.Text);
            }
            CRUDPagina window = new CRUDPagina();
            window.Show();
            this.Close();
        }
    }
}
