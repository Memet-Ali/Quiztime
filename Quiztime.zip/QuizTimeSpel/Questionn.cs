﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using MySqlConnector;

namespace QuizTimeSpel
{

    class Questionn
    {
        private Int32 _question_ID;
        private string _Question;
        private Int32 _Quiz_id;
        private Int32 _next_id;
        private string _img;

        public string img
        {
            get { return _img; }
            set { _img = value; }
        }

        public Int32 question_ID
        {
            get { return _question_ID; }
            set { _question_ID = value; }
        }

        public Int32 Next_id
        {
            get { return _next_id; }
            set { _next_id = value; }
        }
        
        public string Question
        {
            get { return _Question; }
            set { _Question = value; }
        }
        public Int32 Quiz_id
        {
            get { return _Quiz_id; }
            set { _Quiz_id = value; }
        }

        SQL sql = new SQL();
        Answer answer = new Answer();

        public DataSet getData(Int32 ID)
        {
            string SQL = string.Format("SELECT ID, Question, quiz_ID FROM quiztime.question WHERE quiz_ID = {0}", ID);

            return sql.getDataSet(SQL);
        }

        public void ReadQuestion(Int32 ID)
        {
            string SQL = string.Format("SELECT ID, Question, Question_Photo FROM quiztime.question WHERE ID = {0}", ID);
            DataTable datatable = sql.getDataTable(SQL);
            _question_ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
            _Question = datatable.Rows[0]["Question"].ToString();
            _img = datatable.Rows[0]["Question_Photo"].ToString();
        }

        public void ReadQuestion(Int32 ID, SpelPagina form)
        {
            string SQL = string.Format("SELECT ID, Question, Question_Photo, quiz_ID FROM quiztime.question WHERE ID = {0} AND quiz_ID={1}", Next_id, ID);
            DataTable datatable = sql.getDataTable(SQL);

            try
            {
                _question_ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
                form.txbQuestion.Text = datatable.Rows[0]["Question"].ToString();
                _Quiz_id = Convert.ToInt32(datatable.Rows[0]["quiz_ID"].ToString());
                form.imgImg.Source = new BitmapImage(new Uri("Imges/" + datatable.Rows[0]["Question_Photo"].ToString(), UriKind.Relative));
            }
            catch (Exception)
            {

                throw new ArgumentException("Quiz over");
            }
        }


        public void ReadQuestion(Int32 ID, KijknaPagina form)
        {
            string SQL = string.Format("SELECT ID, Question, Question_Photo, quiz_ID FROM quiztime.question WHERE ID = {0} AND quiz_ID={1}", Next_id, ID);
            DataTable datatable = sql.getDataTable(SQL);

            try
            {
                _question_ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
                form.txbQuestion.Text = datatable.Rows[0]["Question"].ToString();
                _Quiz_id = Convert.ToInt32(datatable.Rows[0]["quiz_ID"].ToString());
                form.imgImg.Source = new BitmapImage(new Uri("Imges/" + datatable.Rows[0]["Question_Photo"].ToString(), UriKind.Relative));
            }
            catch (Exception)
            {

                throw new ArgumentException("Quiz over");
            }
        }

        public void GetQuestionID(int Quiz_id)
        {
            string SQL = string.Format("SELECT MIN(q.ID) FROM question AS q INNER JOIN quiz AS x ON x.ID=q.quiz_ID WHERE x.ID={0} AND q.ID>{1}", Quiz_id, _next_id);
            DataTable data = sql.getDataTable(SQL);

            try
            {
                _next_id = Convert.ToInt32(data.Rows[0][0].ToString());
            }
            catch (Exception)
            {

                throw new ArgumentException("Quiz over");
            }
        }


        // CRUD

        public void Create_question(string Question, string imageName, int Q_ID, ref int lastid)
        {
            string SQL = string.Format("INSERT INTO quiztime.question (Question, Question_Photo, quiz_ID) VALUES ('{0}', '{1}', '{2}')", Question, imageName, Q_ID);
            sql.ExecuteNonQuery(SQL);
            lastid = sql.LastInsertedID;
        }
        public DataSet getDataQuestion()
        {
            string SQL = "SELECT ID, Question, Question_Photo, quiz_ID FROM quiztime.question";

            return sql.getDataSet(SQL);
        }

        public bool DeleteQ(Int32 ID)
        {
            bool isDeleted = false;
            if (System.Windows.MessageBox.Show("Moeten deze gegevens verwijderd worden?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {

                string SQL1 = string.Format("DELETE FROM quiztime.question WHERE ID = {0};", ID);
                answer.DeleteAllAnswers_Question(ID);
                sql.ExecuteNonQuery(SQL1);
                isDeleted = true;

            }
            return isDeleted;
        }

        public void DeleteAllQuestion_quiz(Int32 Quiz_ID)
        {
           
                string SQL1 = string.Format("DELETE FROM quiztime.question WHERE quiz_ID = {0};", Quiz_ID);
                
                sql.ExecuteNonQuery(SQL1);


            
        }


        public void UpdateQuestion(int id, string QP, string Question)
        {
            string SQL = string.Format("Update quiztime.question " +
                                       "Set Question  = '{0}', " +
                                       "Question_Photo = '{1}' " +
                                       "WHERE ID =  {2}",
                                                                    Question,
                                                                    QP,
                                                                    id.ToString());
            sql.ExecuteNonQuery(SQL);
        }
    }
}
