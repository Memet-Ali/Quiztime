﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using MySqlConnector;

namespace QuizTimeSpel
{

    class Quiz
    {
        private Int32 _ID;
        private string _Quiz_name;
        private DateTime _Quiz_modified;

        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        public string Quiz_name
        {
            get { return _Quiz_name; }
            set { _Quiz_name = value; }
        }
      
        public DateTime Quiz_modified
        {
            get { return _Quiz_modified; }
            set { _Quiz_modified = value; }
        }

        SQL sql = new SQL();
        

        public DataSet getData()
        {
            string SQL = "SELECT ID, Quiz_name FROM quiztime.quiz";

            return sql.getDataSet(SQL);
        }

        // CRUD
        public void Create(string Quiz_name)
        {
            string SQL = string.Format("INSERT INTO quiztime.quiz (Quiz_name) VALUES ('{0}')",
                        Quiz_name);

            sql.ExecuteNonQuery(SQL);
        }
        public void Read(Int32 ID)
        {
            string SQL = string.Format("SELECT ID, Quiz_name FROM quiztime.quiz WHERE ID = {0}", ID);
            DataTable datatable = sql.getDataTable(SQL);
            _ID = Convert.ToInt32(datatable.Rows[0]["ID"].ToString());
            _Quiz_name = datatable.Rows[0]["Quiz_name"].ToString();
        }
        public void Update(string id, string quiz_name)
        {
            string SQL = string.Format("Update quiztime.quiz " +
                                       "Set Quiz_name  = '{0}' " +
                                       "WHERE ID =  {1}",
                                                                    quiz_name,
                                                                    id.ToString());
            sql.ExecuteNonQuery(SQL);
        }
        public bool Delete(Int32 ID)
        {
            bool isDeleted = false;
            if (System.Windows.MessageBox.Show("Moeten deze gegevens verwijderd worden?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                string SQL = string.Format("DELETE FROM quiztime.quiz WHERE ID = {0};", ID);
                Questionn Q = new Questionn();
                Answer A = new Answer();
                Q.DeleteAllQuestion_quiz(ID);
                A.DeleteAllAnswers_Quiz(ID);
                sql.ExecuteNonQuery(SQL);

                isDeleted = true;

            }
            return isDeleted;
        }
    }
}