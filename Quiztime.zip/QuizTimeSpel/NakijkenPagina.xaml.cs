﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for NakijkenPagina.xaml
    /// </summary>
    public partial class NakijkenPagina : Window
    {
        SQL sql = new SQL();
        public NakijkenPagina()
        {
            InitializeComponent();
            btnSpellen.Click += BtnSpellen_Click;
            btnBackMain.Click += BtnBackMain_Click;
            CbQuizSpel.SelectionChanged += CbQuizSpel_SelectionChanged;
            sql.ComboBoxQuizjes(CbQuizSpel, lblQuizID);

        }

        private void CbQuizSpel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            QuizItem q = (QuizItem)CbQuizSpel.SelectedItem;
            lblQuizID.Content = q.id;
        }

        private void BtnBackMain_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void BtnSpellen_Click(object sender, RoutedEventArgs e)
        {
            KijknaPagina nakijken = new KijknaPagina(Convert.ToInt32(lblQuizID.Content));
            nakijken.Show();
        }
    }
}
