﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace QuizTimeSpel
{
    /// <summary>
    /// Interaction logic for ToevoegenPagina.xaml
    /// </summary>
    public partial class ToevoegenPagina : Window
    {
        SQL quiz = new SQL();
        Questionn QA = new Questionn();
        Answer answer = new Answer();
        public string imageName;
        public ToevoegenPagina()
        {
            InitializeComponent();
            btnVraagToe.Click += BtnVraagToe_Click;
            btnQuizToe.Click += BtnQuizToe_Click;
            btnTerug.Click += BtnTerug_Click;
            btnQuizAanmaken.Click += BtnQuizAanmaken_Click;
            quiz.ComboBoxQuizjes(cbQuizs, label1);
            btnMainWindow.Click += BtnMainWindow_Click;
            cbQuizs.SelectionChanged += CbQuizs_SelectionChanged;
            btnFoto.Click += BtnFoto_Click;
        }

        private void BtnFoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG|*.jpg", ValidateNames = true, Multiselect = false };
            {
                bool? result = ofd.ShowDialog();
                if (result == true)
                {
                    string file = string.Empty;
                    file = ofd.SafeFileName;
                    lblFotoNaam.Content = file;
                    imageName = file;
                }
                else
                {
                    MessageBox.Show("Je hebt geen afbeelding geselecteerd");
                }
            }
        }

        private void CbQuizs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            QuizItem q = (QuizItem)cbQuizs.SelectedItem;
            lblQuizId.Content = q.id;
        }

        private void BtnMainWindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void BtnQuizAanmaken_Click(object sender, RoutedEventArgs e)
        {
            QuizToevoegPagina window = new QuizToevoegPagina();
            window.Show();
            this.Close();
        }

        private void BtnTerug_Click(object sender, RoutedEventArgs e)
            {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

            private void VragenVisibility()
            {
            btnVraagToe.Visibility = Visibility.Hidden;
            btnQuizToe.Visibility = Visibility.Hidden;
            label1.Visibility = Visibility.Visible;
            label3.Visibility = Visibility.Visible;
            label4.Visibility = Visibility.Visible;
            label5.Visibility = Visibility.Visible;
            label6.Visibility = Visibility.Visible;
            label7.Visibility = Visibility.Visible;
            btnQuizAanmaken.Visibility = Visibility.Visible;
            txbAntwoord1.Visibility = Visibility.Visible;
            txbAntwoord2.Visibility = Visibility.Visible;
            txbAntwoord3.Visibility = Visibility.Visible;
            txbGoed.Visibility = Visibility.Visible;
            txbVraag.Visibility = Visibility.Visible;
            cbQuizs.Visibility = Visibility.Visible;
            btnToevoeg.Visibility = Visibility.Visible;
            lblQuizId.Visibility = Visibility.Visible;
            btnFoto.Visibility = Visibility.Visible;
            }


            private void BtnVraagToe_Click(object sender, RoutedEventArgs e)
            {
                VragenVisibility();
            }

            private void BtnQuizToe_Click(object sender, RoutedEventArgs e)
            {
            QuizToevoegPagina window = new QuizToevoegPagina();
            window.Show();
            this.Close();
        }

        private void btnToevoeg_Click(object sender, RoutedEventArgs e)
        {

            if (txbAntwoord1.Text == string.Empty || txbAntwoord2.Text == string.Empty || txbAntwoord3.Text == string.Empty
                || txbGoed.Text == string.Empty || txbVraag.Text == string.Empty)
            {
                lblError.Content = "Vul het formulier volledig in!";
                return;

            }
            else if (cbQuizs.SelectedValue == null || string.IsNullOrEmpty(cbQuizs.Text))
            {
                lblError.Content = "Kies een quiz waar jij de vraag wilt invoegen!";
                return;
            }

            else
            {
                lblError.Content = "Er is een nieuwe vraag toegevoegd aan de quiz " + cbQuizs.Text + "!";
                lblError.Foreground = Brushes.LightSeaGreen;

            }


            int last_created_questionID = -1;


            QA.Create_question(txbVraag.Text, imageName, Convert.ToInt32(lblQuizId.Content), ref last_created_questionID);

            answer.Create_answer(txbAntwoord1.Text, Convert.ToInt32(last_created_questionID), Convert.ToInt32(lblQuizId.Content));
            answer.Create_answer(txbAntwoord2.Text, Convert.ToInt32(last_created_questionID), Convert.ToInt32(lblQuizId.Content));
            answer.Create_answer(txbAntwoord3.Text, Convert.ToInt32(last_created_questionID), Convert.ToInt32(lblQuizId.Content));
            answer.Create_Currect_answer(txbGoed.Text, Convert.ToInt32(last_created_questionID), Convert.ToInt32(lblQuizId.Content));
        }
    }
    }
